#npm install http-server -g
http-server docs